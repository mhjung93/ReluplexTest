#!/bin/bash

./configure --disable-shared --prefix=`pwd`/installed
